import React, { Component } from 'react';

class NotFound extends Component {
    render() {
        return (
            <div className="card w-25 h-100 ml-auto mr-auto mt-5">
           
        <div className="card-body login-card-body">
          <p className="login-box-msg">404 Not found</p>
         
      
          
        </div>
        {/* /.form-box */}
      </div>
        );
    }
}

export default NotFound;