import React, { useState, useEffect, useContext } from 'react';
import {
  Container,
  Grid,
  Card,
  CardContent,
  Typography,
  Box,
  Paper,
  LinearProgress,
  Chip
} from '@mui/material';
import { url as url_base } from '../../Config';
import axios from 'axios';
import AuthContext from '../../AuthProvider/AuthContext';
import TaskPlanTable from './TaskPlanTable/TaskPlanTable';

const TaskPlanDashboard = () => {
  const { state: authState } = useContext(AuthContext);
  const { token } = authState;

  const [todayTasksCount, setTodayTasksCount] = useState(0);
  const [incompleteTasksCount, setIncompleteTasksCount] = useState(0);
  const [loadingStats, setLoadingStats] = useState(true);

  useEffect(() => {
    fetchTaskStats();
  }, []);

  const fetchTaskStats = async () => {
    try {
      setLoadingStats(true);
      
      // 获取今天任务数量
      const todayResponse = await axios.get(`${url_base}/api/db/task-plans/today-tasks/`, {
        headers: {
          'Authorization': `Token ${token}`
        }
      });
      setTodayTasksCount(todayResponse.data.count || 0);

      // 获取未完成任务数量
      const incompleteResponse = await axios.get(`${url_base}/api/db/task-plans/incomplete-tasks/`, {
        headers: {
          'Authorization': `Token ${token}`
        }
      });
      setIncompleteTasksCount(incompleteResponse.data.count || 0);
    } catch (error) {
      console.error('获取任务统计失败:', error);
    } finally {
      setLoadingStats(false);
    }
  };

  return (
    <Container maxWidth={false} sx={{ py: 3, px: 1 }}>
      {/* 统计卡片区域 */}
      <Grid container spacing={3} sx={{ mb: 3 }}>
        <Grid item xs={12} sm={6} md={3}>
          <Card>
            <CardContent>
              <Typography variant="h6" color="textSecondary" gutterBottom>
                今日任务计划
              </Typography>
              <Typography variant="h4" component="h2">
                {loadingStats ? '加载中...' : todayTasksCount}
              </Typography>
              <Box sx={{ mt: 1 }}>
                <LinearProgress 
                  variant="determinate" 
                  value={100} 
                  sx={{ height: 6, borderRadius: 3 }}
                />
              </Box>
            </CardContent>
          </Card>
        </Grid>

        <Grid item xs={12} sm={6} md={3}>
          <Card>
            <CardContent>
              <Typography variant="h6" color="textSecondary" gutterBottom>
                未完成任务
              </Typography>
              <Typography variant="h4" component="h2">
                {loadingStats ? '加载中...' : incompleteTasksCount}
              </Typography>
              <Box sx={{ mt: 1 }}>
                <LinearProgress 
                  variant="determinate" 
                  value={100} 
                  color="warning"
                  sx={{ height: 6, borderRadius: 3 }}
                />
              </Box>
            </CardContent>
          </Card>
        </Grid>
      </Grid>

      {/* 任务计划表格 */}
      <Paper sx={{ mt: 3 }}>
        <TaskPlanTable />
      </Paper>
    </Container>
  );
};

export default TaskPlanDashboard;