const LanguageSwitcher = () => {
  // 现在只支持中文，所以隐藏语言切换器
  return null;
};

export default LanguageSwitcher;