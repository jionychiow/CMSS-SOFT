



import React, { Component } from 'react';
import Nav from '../Nav/Nav'
import Sidebar from "../Sidebar/Sidebar"
class Main extends Component {
    render() {
        return (
            <>
              <Nav></Nav>
                <Sidebar/>
            </>
        );
    }
}

export default Main;

 
