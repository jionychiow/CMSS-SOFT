import React, { useState, useEffect, useCallback, useContext } from 'react';
import {
  Container,
  Paper,
  Box,
  Grid,
  Typography,
  TextField,
  Button,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Snackbar,
  Alert,
  InputAdornment,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  useMediaQuery,
  useTheme,
  Chip,
  Toolbar,
  Tooltip,
  Autocomplete,
  CircularProgress
} from '@mui/material';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { DateTimePicker } from '@mui/x-date-pickers/DateTimePicker';
import { AdapterDateFns } from '@mui/x-date-pickers/AdapterDateFns';
import zhCN from 'date-fns/locale/zh-CN';
import { Add as AddIcon, FilterList as FilterIcon, Download as DownloadIcon, Upload as UploadIcon } from '@mui/icons-material';
import { styled } from '@mui/material/styles';
import { useLocation, useSearchParams } from 'react-router-dom';
import axios from 'axios';
import { url } from '../../Config';
import AuthContext from '../../AuthProvider/AuthContext';

// 定义字段配置
const FIELD_CONFIG = {
  long_day_shift: [
    { key: 'serial_number', label: '序号', required: true },
    { key: 'month', label: '月份', required: true },
    { key: 'production_line', label: '产线', required: true },
    { key: 'process', label: '工序', required: true },
    { key: 'equipment_name', label: '设备或工装名称', required: true },
    { key: 'equipment_number', label: '设备编号', required: true },
    { key: 'equipment_part', label: '设备零部件/部位', required: true },
    { key: 'change_reason', label: '变更原因', required: true },
    { key: 'before_change', label: '变更前(现状)', required: true },
    { key: 'after_change', label: '变更后（变了什么）', required: true },
    { key: 'start_date_time', label: '开始日期及时间', required: true },
    { key: 'end_date_time', label: '结束日期及时间', required: true },
    { key: 'duration', label: '耗用时长', required: false },
    { key: 'parts_consumables', label: '零件耗材', required: true },
    { key: 'implementer', label: '实施人', required: true },
    { key: 'acceptor', label: '验收人', required: true },
    { key: 'remarks', label: '备注', required: false }
  ],
  rotating_shift: [
    { key: 'serial_number', label: '序号', required: true },
    { key: 'month', label: '月份', required: true },
    { key: 'production_line', label: '产线', required: true },
    { key: 'process', label: '工序', required: true },
    { key: 'equipment_name', label: '设备或工装名称', required: true },
    { key: 'equipment_number', label: '设备编号', required: true },
    { key: 'equipment_part', label: '设备零部件/部位', required: true },
    { key: 'change_reason', label: '变更原因', required: true },
    { key: 'before_change', label: '变更前(现状)', required: true },
    { key: 'after_change', label: '变更后（变了什么）', required: true },
    { key: 'start_date_time', label: '开始日期及时间', required: true },
    { key: 'end_date_time', label: '结束日期及时间', required: true },
    { key: 'duration', label: '耗用时长', required: false },
    { key: 'parts_consumables', label: '零件耗材', required: true },
    { key: 'implementer', label: '实施人', required: true },
    { key: 'acceptor', label: '验收人', required: true },
    { key: 'remarks', label: '备注', required: false }
  ]
};

const ActionButton = styled(Button)(({ theme }) => ({
  borderRadius: 8,
  fontWeight: 600,
  textTransform: 'none',
  boxShadow: '0 2px 8px rgba(0, 0, 0, 0.1)',
  '&:hover': {
    boxShadow: '0 4px 12px rgba(0, 0, 0, 0.15)',
    transform: 'translateY(-1px)',
  },
}));

const PhaseShiftMaintenanceRecords = () => {
  const [records, setRecords] = useState([]);
  const [filteredRecords, setFilteredRecords] = useState([]);
  const [openForm, setOpenForm] = useState(false);
  const [currentRecord, setCurrentRecord] = useState(null);
  const [formData, setFormData] = useState({});
  const [searchTerm, setSearchTerm] = useState('');
  const [snackbar, setSnackbar] = useState({ open: false, message: '', severity: 'success' });

  const [showFilters, setShowFilters] = useState(true);

  const { state: authState } = useContext(AuthContext);
  const { token, user_profile } = authState;
  const location = useLocation();
  const [searchParams] = useSearchParams();
  const urlPhase = searchParams.get('phase');
  const urlShiftType = searchParams.get('shift_type');

  // 辅助函数：为特定字段设置最小宽度
  const getMinWidthForField = (fieldKey) => {
    switch (fieldKey) {
      case 'month':
        return '40px';
      case 'production_line':
        return '40px';
      case 'process':
        return '40px';
      case 'duration':
        return '70px';
      case 'start_date_time':
      case 'end_date_time':
        return '100px';
      case 'serial_number':
        return '70px';
      case 'equipment_name':
      case 'equipment_part':
        return '100px';
      default:
        return '90px';
    }
  };

  // 根据用户权限确定当前的工厂分期和班次类型
  const getUserPhase = () => {
    if (user_profile && user_profile.plant_phase) {
      // 如果用户类型是Admin，允许访问所有阶段
      if (user_profile.type === 'Admin') {
        // 如果URL参数为空，返回默认值；否则返回URL参数
        return effectivePhase || 'phase_1'; 
      }
      return user_profile.plant_phase;
    }
    // 默认返回一期，如果没有权限信息
    return 'phase_1';
  };

  const getUserShiftType = () => {
    if (user_profile && user_profile.shift_type) {
      // 如果用户类型是Admin，允许访问所有班次
      if (user_profile.type === 'Admin') {
        // 如果URL参数为空，返回默认值；否则返回URL参数
        return effectiveShiftType || 'long_day_shift';
      }
      return user_profile.shift_type;
    }
    // 默认返回长白班，如果没有权限信息
    return 'long_day_shift';
  };

  // 如果URL参数不存在，则使用用户权限确定的值
  const effectivePhase = urlPhase || getUserPhase();
  const effectiveShiftType = urlShiftType || getUserShiftType();

  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('md'));
  const isExtraSmall = useMediaQuery(theme.breakpoints.down('sm'));

  // 检查当前用户是否有删除权限
  const hasDeletePermission = user_profile?.type === 'Admin' || user_profile?.can_delete_maintenance_records;

  // 定义样式组件
  const StyledPaper = styled(Paper)(({ theme }) => ({
    borderRadius: isMobile ? 8 : 16,
    boxShadow: isMobile ? '0 4px 16px rgba(0, 0, 0, 0.1)' : '0 8px 32px rgba(0, 0, 0, 0.1)',
    background: 'linear-gradient(135deg, rgba(255, 255, 255, 0.9) 0%, rgba(245, 247, 250, 0.9) 100%)',
    backdropFilter: 'blur(10px)',
    border: '1px solid rgba(255, 255, 255, 0.2)',
    overflow: 'hidden',
  }));

  const HeaderCard = styled(Box)(({ theme }) => ({
    background: 'linear-gradient(135deg, #1976d2 0%, #2196f3 100%)',
    color: 'white',
    borderRadius: isMobile ? '12px' : '16px',
    padding: isMobile ? '16px' : '24px',
    marginBottom: isMobile ? '16px' : '32px',
    boxShadow: isMobile ? '0 4px 16px rgba(25, 118, 210, 0.3)' : '0 8px 32px rgba(25, 118, 210, 0.3)',
  }));

  // 获取字段配置
  const getFieldConfig = () => {
    if (!effectiveShiftType) return [];
    return FIELD_CONFIG[effectiveShiftType] || [];
  };

  // 获取表单字段配置（排除序号和月份字段，因为它们在表单中只读显示）
  const getFormFieldsConfig = () => {
    if (!effectiveShiftType) return [];
    const allFields = FIELD_CONFIG[effectiveShiftType] || [];
    // 排除序号和月份字段，因为它们在表单中只读显示
    return allFields.filter(field => field.key !== 'serial_number' && field.key !== 'month');
  };

  // 获取字段值
  const getFieldValue = (record, fieldKey) => {
    if (fieldKey === 'phase_display') {
      return record.phase === 'phase_1' ? '一期' : '二期';
    }
    if (fieldKey === 'shift_type_display') {
      return record.shift_type === 'long_day_shift' ? '长白班' : '倒班';
    }
    // 处理后端字段名与前端显示字段名不匹配的情况
    if (fieldKey === 'serial_number') {
      return record.serial_number || '';
    }
    if (fieldKey === 'month') {
      return record.month || '';
    }
    return record[fieldKey] || '';
  };

  // 获取表单初始值
  const getInitialFormValues = () => {
    const config = getFormFieldsConfig(); // 使用更新后的表单字段配置
    const initialValues = {};
    
    config.forEach(field => {
      initialValues[field.key] = '';
    });
    
    if (effectivePhase) {
      initialValues['phase'] = effectivePhase;
    }
    if (effectiveShiftType) {
      initialValues['shift_type'] = effectiveShiftType;
    }
    
    return initialValues;
  };

  // 显示通知
  const showSnackbar = useCallback((message, severity) => {
    setSnackbar({ open: true, message, severity });
  }, []);

  // 获取记录
  const fetchRecords = useCallback(async () => {
    try {
      const response = await axios.get(`${url}/api/db/shift-maintenance-records/`, {
        headers: {
          Authorization: `Token ${token}`,
        },
        params: {
          phase: effectivePhase,
          shift_type: effectiveShiftType
        }
      });
      setRecords(response.data);
      setFilteredRecords(response.data);
    } catch (error) {
      console.error('获取记录失败:', error);
      showSnackbar('获取记录失败', 'error');
    }
  }, [token, effectivePhase, effectiveShiftType, showSnackbar]);

  // 获取记录带过滤
  const fetchRecordsWithFilters = useCallback(async (phase, shiftType) => {
    try {
      const response = await axios.get(`${url}/api/db/shift-maintenance-records/`, {
        headers: {
          Authorization: `Token ${token}`,
        },
        params: {
          phase: phase,
          shift_type: shiftType
        }
      });
      setRecords(response.data);
      setFilteredRecords(response.data);
    } catch (error) {
      console.error('获取记录失败:', error);
      showSnackbar('获取记录失败', 'error');
    }
  }, [token, showSnackbar]);

  // 创建记录
  const createRecord = async (data) => {
    try {
      const response = await axios.post(
        `${url}/api/db/shift-maintenance-records/`,
        data,
        {
          headers: {
            Authorization: `Token ${token}`,
            'Content-Type': 'application/json',
          },
        }
      );
      
      setRecords([...records, response.data]);
      setFilteredRecords([...records, response.data]);
      showSnackbar('记录创建成功', 'success');
    } catch (error) {
      console.error('创建记录失败:', error);
      showSnackbar('创建记录失败', 'error');
    }
  };

  // 更新记录
  const updateRecord = async (id, data) => {
    try {
      const response = await axios.put(
        `${url}/api/db/shift-maintenance-records/${id}/`,
        data,
        {
          headers: {
            Authorization: `Token ${token}`,
            'Content-Type': 'application/json',
          },
        }
      );
      
      const updatedRecords = records.map((record) =>
        record.id === id ? response.data : record
      );
      setRecords(updatedRecords);
      setFilteredRecords(updatedRecords);
      showSnackbar('记录更新成功', 'success');
    } catch (error) {
      console.error('更新记录失败:', error);
      showSnackbar('更新记录失败', 'error');
    }
  };

  // 删除记录
  const deleteRecord = async (id) => {
    try {
      await axios.delete(`${url}/api/db/shift-maintenance-records/${id}/`, {
        headers: {
          Authorization: `Token ${token}`,
        },
      });
      
      const updatedRecords = records.filter((record) => record.id !== id);
      setRecords(updatedRecords);
      setFilteredRecords(updatedRecords);
      showSnackbar('记录删除成功', 'success');
    } catch (error) {
      console.error('删除记录失败:', error);
      showSnackbar('删除记录失败', 'error');
    }
  };

  // 处理搜索
  const handleSearch = (event) => {
    const term = event.target.value.toLowerCase();
    setSearchTerm(term);
    
    const filtered = records.filter((record) =>
      Object.values(record).some(
        (value) =>
          value &&
          value.toString().toLowerCase().includes(term)
      )
    );
    
    setFilteredRecords(filtered);
  };

  // 打开表单
  const handleOpenForm = (record = null) => {
    setCurrentRecord(record);
    if (record) {
      setFormData({ ...record });
    } else {
      setFormData(getInitialFormValues());
    }
    setOpenForm(true);
  };

  // 关闭表单
  const handleCloseForm = () => {
    setOpenForm(false);
    setCurrentRecord(null);
    setFormData(getInitialFormValues());
  };

  // 提交表单
  const handleSubmit = async (event) => {
    event.preventDefault();
    
    // 准备要提交的数据
    let submitData = {
      ...formData,
      phase: effectivePhase,
      shift_type: effectiveShiftType
    };
    
    // 对于新建记录，移除序号和月份字段，让后端自动生成
    if (!currentRecord) {
      const { serial_number, month, ...rest } = submitData;
      submitData = rest;
    }
    
    if (currentRecord) {
      await updateRecord(currentRecord.id, submitData);
    } else {
      await createRecord(submitData);
    }
    
    handleCloseForm();
  };

  // 处理筛选器变化
  const [filters, setFilters] = useState({
    startDate: '',
    endDate: '',
    productionLine: ''
  });
  
  // Excel功能相关状态
  const [openDownloadDialog, setOpenDownloadDialog] = useState(false);
  const [downloadFilters, setDownloadFilters] = useState({
    phase: effectivePhase || '',
    shift_type: effectiveShiftType || ''
  });
  const [selectedFile, setSelectedFile] = useState(null);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [uploading, setUploading] = useState(false);

  // 应用筛选器
  useEffect(() => {
    let filtered = records;

    if (filters.startDate) {
      filtered = filtered.filter(record => new Date(record.start_date_time) >= new Date(filters.startDate));
    }
    if (filters.endDate) {
      filtered = filtered.filter(record => new Date(record.end_date_time) <= new Date(filters.endDate));
    }
    if (filters.productionLine) {
      filtered = filtered.filter(record => 
        record.production_line && 
        record.production_line === filters.productionLine
      );
    }

    setFilteredRecords(filtered);
  }, [filters, records]);

  // 添加状态变量
  const [assets, setAssets] = useState([]); // 存储设备数据
  const [configData, setConfigData] = useState({ // 存储配置数据
    phases: [],
    productionLines: [],
    processes: [],
    shiftTypes: []
  }); 
  const [implementersOptions, setImplementersOptions] = useState([]); // 实施人选项
  const [selectedImplementers, setSelectedImplementers] = useState([]); // 已选择的实施人

  // 获取配置数据
  const fetchConfigData = useCallback(async () => {
    try {
      console.log('PhaseShiftMaintenanceRecords - 开始获取配置数据...');
      console.log('PhaseShiftMaintenanceRecords - Token:', token ? '存在' : '不存在');
      
      const response = await axios.get(`${url}/api/maintenance/config/get-config-data/`, {
              headers: {
                Authorization: `Token ${token}`,
              },
            });
      
      console.log('PhaseShiftMaintenanceRecords - API响应数据:', response.data);
      setConfigData(response.data);
      
      console.log('PhaseShiftMaintenanceRecords - 配置数据设置完成:', {
        phasesCount: response.data.phases?.length || 0,
        productionLinesCount: response.data.productionLines?.length || 0,
        processesCount: response.data.processes?.length || 0
      });
    } catch (error) {
      console.error('PhaseShiftMaintenanceRecords - 获取配置数据失败:', error);
      // 详细错误信息
      if (error.response) {
        console.error('Response data:', error.response.data);
        console.error('Response status:', error.response.status);
        console.error('Response headers:', error.response.headers);
      } else if (error.request) {
        console.error('Request data:', error.request);
      } else {
        console.error('Error message:', error.message);
      }
    }
  }, [token]); // url是常量，不需要作为依赖

  // 获取设备数据
  const fetchAssets = useCallback(async () => {
    try {
      const response = await axios.get(`${url}/api/db/assets/`, {
        headers: {
          Authorization: `Token ${token}`,
        },
      });
      setAssets(response.data);
    } catch (error) {
      console.error('获取设备数据失败:', error);
    }
  }, [token]);

  // 获取所有用户作为实施人选项
  const fetchUsers = useCallback(async () => {
    try {
      const response = await axios.get(`${url}/api/user-management/list-users/`, {
        headers: {
          Authorization: `Token ${token}`,
        },
      });
      // 只取用户名作为选项
      // API返回的是用户数组，而不是{users: [...]}结构
      const users = response.data.map(user => user.username);
      setImplementersOptions(users);
    } catch (error) {
      console.error('获取用户数据失败:', error);
    }
  }, [token]);

  // 初始化配置数据、资产和用户数据
  useEffect(() => {
    fetchConfigData();
    fetchAssets();
    fetchUsers();
  }, [fetchConfigData, fetchAssets, fetchUsers]);

  // 当配置数据加载完成后，初始化表单
  useEffect(() => {
    if (configData.phases && configData.phases.length > 0 && 
        configData.productionLines && configData.productionLines.length > 0 && 
        configData.processes && configData.processes.length > 0 && 
        assets && assets.length > 0 && 
        implementersOptions && implementersOptions.length > 0) {
      // 如果是新建记录，设置默认值
      if (!currentRecord && openForm) {
        setFormData(prev => ({
          ...prev,
          start_date_time: new Date(),
          end_date_time: new Date(),
          implementer: authState.user_profile?.username || '' // 默认为当前用户名
        }));
      }
    }
  }, [configData, assets, implementersOptions, currentRecord, openForm, authState.user_profile]);

  // 处理实施人选择变化
  const handleImplementersChange = (newValue) => {
    // 确保第一个实施人始终是当前用户
    const currentUser = authState.user_profile?.username || '';
    if (newValue.length > 0 && newValue[0] !== currentUser) {
      // 如果当前用户不在第一位，则添加到第一位
      if (newValue.includes(currentUser)) {
        // 如果当前用户在列表中，移到第一位
        const filtered = newValue.filter(name => name !== currentUser);
        setSelectedImplementers([currentUser, ...filtered]);
      } else {
        // 如果当前用户不在列表中，添加到第一位
        setSelectedImplementers([currentUser, ...newValue]);
      }
    } else {
      setSelectedImplementers(newValue);
    }
  };

  // 处理表单变化
  const handleInputChange = (event) => {
    const { name, value } = event.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };

  // 处理日期时间变化
  const handleDateTimeChange = (name, value) => {
    let updatedFormData = {
      ...formData,
      [name]: value,
    };
    
    // 如果是开始时间或结束时间改变，自动计算耗用时长
    if (name === 'start_date_time' || name === 'end_date_time') {
      const startDate = updatedFormData.start_date_time;
      const endDate = updatedFormData.end_date_time;
      
      if (startDate && endDate) {
        // 计算时间差（毫秒）
        const startTime = new Date(startDate).getTime();
        const endTime = new Date(endDate).getTime();
        
        if (!isNaN(startTime) && !isNaN(endTime)) {
          // 计算时间差（小时）
          const durationHours = (endTime - startTime) / (1000 * 60 * 60);
          const roundedDuration = Math.round(durationHours * 2) / 2; // 保留一位小数
          
          // 只有当时间差为正数时才设置耗用时长
          if (roundedDuration > 0) {
            updatedFormData = {
              ...updatedFormData,
              duration: roundedDuration.toString() // 转换为字符串以适应TextField
            };
          } else {
            updatedFormData = {
              ...updatedFormData,
              duration: '' // 时间差为负或零时清空耗用时长
            };
          }
        }
      }
    }
    
    setFormData(updatedFormData);
  };

  // 处理实施人多选变化
  const handleMultiSelectChange = (name, value) => {
    setFormData({
      ...formData,
      [name]: Array.isArray(value) ? value.join(', ') : value,
    });
  };

  // 监听URL参数变化
  useEffect(() => {
    if (effectivePhase && effectiveShiftType) {
      fetchRecords();
    }
  }, [effectivePhase, effectiveShiftType, fetchRecords, token]);

  // 自动设置用户权限对应的phase和shift_type（仅当URL参数缺失时）
  useEffect(() => {
    if (!urlPhase || !urlShiftType) {
      // 如果URL中没有参数，且用户有权限信息，则自动重定向到对应的页面
      if (user_profile && user_profile.plant_phase && user_profile.shift_type) {
        // 不需要手动重定向，因为effectivePhase和effectiveShiftType已经基于用户权限设置了
        // 数据获取会自动使用这些值
      }
    }
  }, [urlPhase, urlShiftType, user_profile]);

  // 监听URL参数变化，如果变化则重新获取数据
  useEffect(() => {
    const params = new URLSearchParams(location.search);
    const newUrlPhase = params.get('phase');
    const newUrlShiftType = params.get('shift_type');
    
    if (newUrlPhase !== urlPhase || newUrlShiftType !== urlShiftType) {
      // 如果URL参数发生变化，重新获取数据
      if (newUrlPhase && newUrlShiftType) {
        fetchRecordsWithFilters(newUrlPhase, newUrlShiftType);
      }
    }
  }, [location.search, fetchRecordsWithFilters, urlPhase, urlShiftType, token]);

  // 处理下载模板
  const handleDownloadTemplate = async () => {
    try {
      const response = await axios.get(`${url}/api/excel/download-template/`, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
        responseType: 'blob' // 重要：指定响应类型为blob
      });
      
      // 创建下载链接
      const blob = new Blob([response.data], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
      const downloadUrl = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = downloadUrl;
      link.setAttribute('download', '维修记录模板.xlsx');
      document.body.appendChild(link);
      link.click();
      link.remove();
      window.URL.revokeObjectURL(downloadUrl);
      
      showSnackbar('模板下载成功', 'success');
    } catch (error) {
      console.error('下载模板失败:', error);
      showSnackbar('下载模板失败', 'error');
    }
  };

  // 处理下载记录
  const handleDownloadRecords = async () => {
    try {
      const response = await axios.post(`${url}/api/excel/download-records/`, downloadFilters, {
        headers: {
          Authorization: `Bearer ${token}`,
          'Content-Type': 'application/json',
        },
        responseType: 'blob' // 重要：指定响应类型为blob
      });
      
      // 创建下载链接
      const blob = new Blob([response.data], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
      const downloadUrl = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = downloadUrl;
      link.setAttribute('download', '维修记录.xlsx');
      document.body.appendChild(link);
      link.click();
      link.remove();
      window.URL.revokeObjectURL(downloadUrl);
      
      showSnackbar('记录下载成功', 'success');
      setOpenDownloadDialog(false);
    } catch (error) {
      console.error('下载记录失败:', error);
      showSnackbar('下载记录失败', 'error');
    }
  };

  // 处理文件选择
  const handleFileSelect = (event) => {
    const file = event.target.files[0];
    if (file) {
      if (file.type === 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' || 
          file.name.endsWith('.xlsx')) {
        setSelectedFile(file);
      } else {
        showSnackbar('请选择Excel文件(.xlsx)', 'error');
      }
    }
  };

  // 处理上传
  const handleUpload = async () => {
    if (!selectedFile) {
      showSnackbar('请选择要上传的文件', 'warning');
      return;
    }

    const formData = new FormData();
    formData.append('file', selectedFile);

    try {
      setUploading(true);
      setUploadProgress(0);

      const response = await axios.post(`${url}/api/excel/upload-records/`, formData, {
        headers: {
          Authorization: `Bearer ${token}`,
          'Content-Type': 'multipart/form-data',
        },
        onUploadProgress: (progressEvent) => {
          const progress = Math.round((progressEvent.loaded * 100) / progressEvent.total);
          setUploadProgress(progress);
        }
      });

      showSnackbar(response.data.message || '文件上传成功', 'success');
      setSelectedFile(null);
      // 重新获取记录以显示新上传的数据
      fetchRecords();
    } catch (error) {
      console.error('上传失败:', error);
      const errorMessage = error.response?.data?.error || '上传失败';
      showSnackbar(errorMessage, 'error');
    } finally {
      setUploading(false);
      setUploadProgress(0);
    }
  };

  // 监听搜索变化
  useEffect(() => {
    if (searchTerm) {
      const filtered = records.filter((record) =>
        Object.values(record).some(
          (value) =>
            value &&
            value.toString().toLowerCase().includes(searchTerm)
        )
      );
      setFilteredRecords(filtered);
    } else {
      setFilteredRecords(records);
    }
  }, [searchTerm, records]);

  // 检查用户是否有足够的权限访问此页面
  if (!user_profile || (!user_profile.plant_phase && user_profile.type !== 'Admin') || (!user_profile.shift_type && user_profile.type !== 'Admin')) {
    return (
      <Container maxWidth="lg" sx={{ mt: 4, mb: 4 }}>
        <Paper elevation={3} sx={{ p: 4, textAlign: 'center' }}>
          <Typography variant="h5" color="error">
            无法获取用户权限信息，请联系管理员
          </Typography>
          <Button 
            variant="contained" 
            color="primary" 
            sx={{ mt: 2 }}
            onClick={() => window.location.href = '/'}
          >
            返回主页
          </Button>
        </Paper>
      </Container>
    );
  }

  const currentShiftTypeDisplay = effectiveShiftType === 'long_day_shift' ? '长白班' : '倒班';
  const currentPhaseDisplay = effectivePhase === 'phase_1' ? '一期' : '二期';

  // 检查配置数据是否已加载
  const isConfigDataLoaded = 
    configData.phases && 
    configData.productionLines && 
    configData.processes &&
    configData.shiftTypes &&
    Array.isArray(configData.phases) && 
    Array.isArray(configData.productionLines) && 
    Array.isArray(configData.processes) &&
    Array.isArray(configData.shiftTypes);
  
  const isAssetsLoaded = assets !== null && assets !== undefined && Array.isArray(assets);

  // 在数据加载完成之前显示加载状态
  if (!isConfigDataLoaded || !isAssetsLoaded) {
    return (
      <Container maxWidth="lg" sx={{ mt: 4, mb: 4 }}>
        <Paper elevation={3} sx={{ p: 4, textAlign: 'center' }}>
          <CircularProgress sx={{ mb: 2 }} />
          <Typography variant="h6" color="textSecondary">
            正在加载配置数据...
          </Typography>
        </Paper>
      </Container>
    );
  }

  // 处理筛选器变化
  const handleFilterChange = (field, value) => {
    setFilters(prev => ({
      ...prev,
      [field]: value
    }));
  };

  return (
    <Container maxWidth={isMobile ? "xs" : "xl"} sx={{ mt: isMobile ? 1 : 2, mb: 4, px: isMobile ? 1 : undefined }}>
      {/* 页面头部 */}
      <HeaderCard>
        <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
          <Box sx={{ flexGrow: 1 }}>
            <Typography variant="h4" component="h1" gutterBottom>
              维修记录管理系统
            </Typography>
            <Typography variant="h6" component="p" sx={{ opacity: 0.9 }}>
              {currentPhaseDisplay} - {currentShiftTypeDisplay} 维修记录
            </Typography>
          </Box>
          <Box sx={{ display: 'flex', gap: 1, alignItems: 'center' }}>
            <Chip 
              label={`${currentPhaseDisplay} - ${currentShiftTypeDisplay}`} 
              color="default" 
              variant="outlined"
              size="large"
              sx={{ 
                bgcolor: 'rgba(255, 255, 255, 0.2)', 
                fontWeight: 600,
                fontSize: '1.1rem',
                height: '48px'
              }}
            />
            <ActionButton 
              variant="contained" 
              color="secondary"
              onClick={() => window.location.href = '/'} 
              sx={{ 
                px: 2,
                minWidth: 'auto',
                ml: 1
              }}
            >
              返回主页
            </ActionButton>
          </Box>
        </Box>
      </HeaderCard>

      <StyledPaper elevation={0} sx={{ p: 0, background: 'transparent' }}>
        <Paper 
          elevation={3} 
          sx={{ 
            borderRadius: isMobile ? 2 : 4, 
            overflow: 'hidden',
            background: 'linear-gradient(135deg, rgba(255, 255, 255, 0.95) 0%, rgba(245, 247, 250, 0.95) 100%)',
            backdropFilter: 'blur(10px)',
            border: '1px solid rgba(255, 255, 255, 0.2)'
          }}
        >
          {/* 操作工具栏 */}
          <Toolbar sx={{ 
            display: 'flex', 
            justifyContent: 'space-between', 
            alignItems: 'center', 
            p: isMobile ? 1 : 2,
            borderBottom: '1px solid #e0e0e0',
            bgcolor: 'rgba(25, 118, 210, 0.05)',
            flexWrap: isMobile ? 'column' : 'row',
            gap: isMobile ? 1 : 0
          }}>
            <Box sx={{ display: 'flex', alignItems: 'center', flexWrap: 'wrap', gap: 1, mb: isMobile ? 1 : 0, order: isMobile ? 2 : 'initial' }}>
              <Chip 
                label={`总计: ${filteredRecords.length} 条`} 
                color="primary" 
                variant="filled"
                size={isExtraSmall ? "small" : "medium"}
                sx={{ fontWeight: 600, height: isMobile ? '32px' : '40px', fontSize: isMobile ? '0.75rem' : '0.875rem' }}
              />
              <Chip 
                label={`筛选后: ${filteredRecords.length} 条`} 
                color="secondary" 
                variant="outlined"
                size={isExtraSmall ? "small" : "medium"}
                sx={{ fontWeight: 600, height: isMobile ? '32px' : '40px', fontSize: isMobile ? '0.75rem' : '0.875rem' }}
              />
            </Box>
            <Box sx={{ display: 'flex', gap: isMobile ? 0.5 : 1, flexWrap: 'wrap', justifyContent: 'flex-end', order: isMobile ? 1 : 'initial' }}>
              <ActionButton 
                variant="contained" 
                color="primary" 
                startIcon={<AddIcon />}
                onClick={() => handleOpenForm()}
                disabled={!user_profile?.can_add_maintenance_records} // 根据权限控制
                sx={{ 
                  px: isExtraSmall ? 1 : isMobile ? 1.5 : 3,
                  minWidth: isMobile ? '100px' : 'auto',
                  mb: isMobile ? 0.5 : 0,
                  fontSize: isMobile ? '0.75rem' : '0.875rem'
                }}
              >
                {isExtraSmall ? '+' : '新建记录'}
              </ActionButton>
              <ActionButton 
                variant={showFilters ? "contained" : "outlined"}
                color="info"
                startIcon={<FilterIcon />}
                onClick={() => setShowFilters(!showFilters)}
                sx={{ 
                  px: isExtraSmall ? 1 : isMobile ? 1.5 : 3,
                  minWidth: isMobile ? '100px' : 'auto',
                  fontSize: isMobile ? '0.75rem' : '0.875rem'
                }}
              >
                {showFilters ? (isExtraSmall ? '隐藏' : '隐藏筛选') : (isExtraSmall ? '筛选' : '显示筛选')}
              </ActionButton>
              
              {/* Excel功能按钮 */}
              <Tooltip title="下载模板用于批量录入">
                <ActionButton 
                  variant="outlined"
                  color="success"
                  startIcon={<DownloadIcon />}
                  onClick={handleDownloadTemplate}
                  sx={{ 
                    px: isExtraSmall ? 0.75 : isMobile ? 1 : 2,
                    minWidth: isMobile ? '80px' : 'auto',
                    fontSize: isMobile ? '0.75rem' : '0.875rem'
                  }}
                >
                  {isExtraSmall ? '模' : isMobile ? '模板' : '下载模板'}
                </ActionButton>
              </Tooltip>
              
              <Tooltip title="下载选定条件的记录">
                <ActionButton 
                  variant="outlined"
                  color="success"
                  startIcon={<DownloadIcon />}
                  onClick={() => setOpenDownloadDialog(true)}
                  sx={{ 
                    px: isExtraSmall ? 0.75 : isMobile ? 1 : 2,
                    minWidth: isMobile ? '80px' : 'auto',
                    fontSize: isMobile ? '0.75rem' : '0.875rem'
                  }}
                >
                  {isExtraSmall ? '出' : isMobile ? '导出' : '导出记录'}
                </ActionButton>
              </Tooltip>
              
              <Tooltip title="上传Excel文件批量导入">
                <label htmlFor="upload-excel">
                  <ActionButton 
                    variant="contained"
                    color="secondary"
                    component="span"
                    startIcon={<UploadIcon />}
                    sx={{ 
                      px: isExtraSmall ? 0.75 : isMobile ? 1 : 2,
                      minWidth: isMobile ? '80px' : 'auto',
                      fontSize: isMobile ? '0.75rem' : '0.875rem'
                    }}
                  >
                    {isExtraSmall ? '入' : isMobile ? '导入' : '批量导入'}
                  </ActionButton>
                </label>
                <input
                  accept=".xlsx"
                  id="upload-excel"
                  type="file"
                  style={{ display: 'none' }}
                  onChange={handleFileSelect}
                />
              </Tooltip>
              
              {selectedFile && (
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, ml: isMobile ? 0 : 1 }}>
                  <Typography variant={isExtraSmall ? "caption" : "body2"} noWrap sx={{ maxWidth: isMobile ? '80px' : '120px', fontSize: isMobile ? '0.75rem' : '0.875rem' }}>
                    {selectedFile.name}
                  </Typography>
                  <ActionButton 
                    variant="contained"
                    color="primary"
                    onClick={handleUpload}
                    disabled={uploading}
                    sx={{ minWidth: isMobile ? '60px' : '70px', fontSize: isMobile ? '0.75rem' : '0.875rem' }}
                  >
                    {uploading ? `${uploadProgress}%` : (isExtraSmall ? '传' : '上传')}
                  </ActionButton>
                </Box>
              )}
            </Box>
          </Toolbar>

          {/* 筛选器 */}
          {showFilters && (
            <Box sx={{ p: isMobile ? 1.5 : 3, bgcolor: 'rgba(245, 247, 250, 0.6)', borderBottom: '1px solid #e0e0e0' }}>
              <Grid container spacing={isMobile ? 1.5 : 2} alignItems="center">
                <Grid item xs={12} sm={6} md={3}>
                  <TextField
                    label="开始日期"
                    type="date"
                    value={filters.startDate}
                    onChange={(e) => handleFilterChange('startDate', e.target.value)}
                    InputLabelProps={{ shrink: true }}
                    fullWidth
                    size={isMobile ? "small" : "medium"}
                  />
                </Grid>
                <Grid item xs={12} sm={6} md={3}>
                  <TextField
                    label="结束日期"
                    type="date"
                    value={filters.endDate}
                    onChange={(e) => handleFilterChange('endDate', e.target.value)}
                    InputLabelProps={{ shrink: true }}
                    fullWidth
                    size={isMobile ? "small" : "medium"}
                  />
                </Grid>
                <Grid item xs={12} sm={6} md={3}>
                  <TextField
                    select
                    label="产线"
                    value={filters.productionLine}
                    onChange={(e) => handleFilterChange('productionLine', e.target.value)}
                    fullWidth
                    size={isMobile ? "small" : "medium"}
                  >
                    <MenuItem value="">全部</MenuItem>
                    {configData.productionLines && configData.productionLines
                      .filter(line => line.phase_code === effectivePhase) // 只显示当前期别的产线
                      .map((line) => (
                        <MenuItem key={line.code || line.name} value={line.code || line.name}>{line.name}</MenuItem>
                      ))}
                  </TextField>
                </Grid>
                <Grid item xs={12} sm={6} md={3}>
                  <Typography variant={isMobile ? "caption" : "body2"} color="text.secondary" sx={{ pt: isMobile ? 0.5 : 0, fontWeight: 500, fontSize: isMobile ? '0.75rem' : '0.875rem' }}>
                    符合条件: {filteredRecords.length} 条记录
                  </Typography>
                </Grid>
              </Grid>
            </Box>
          )}

          {/* 搜索框 */}
          <Box sx={{ p: isMobile ? 1.5 : 3, bgcolor: 'rgba(250, 250, 250, 0.8)' }}>
            <Grid container spacing={isMobile ? 1 : 2} alignItems="center">
              <Grid item xs={12} md={6}>
                <TextField
                  fullWidth
                  label="搜索记录"
                  variant="outlined"
                  value={searchTerm}
                  onChange={handleSearch}
                  size={isMobile ? "small" : "medium"}
                  InputProps={{
                    endAdornment: (
                      <InputAdornment position="end">
                        <Typography variant={isMobile ? "caption" : "body2"}>{filteredRecords.length} 条记录</Typography>
                      </InputAdornment>
                    ),
                  }}
                />
              </Grid>
            </Grid>
          </Box>

          {/* 记录表格 */}
          <Box sx={{ p: isMobile ? 0.5 : 2 }}>
            <TableContainer 
              sx={{ 
                maxHeight: isMobile ? '60vh' : '70vh',
                '&::-webkit-scrollbar': {
                  height: '8px',
                  width: '8px'
                },
                '&::-webkit-scrollbar-track': {
                  background: '#f1f1f1',
                  borderRadius: '4px'
                },
                '&::-webkit-scrollbar-thumb': {
                  background: '#c1c1c1',
                  borderRadius: '4px'
                },
                '&::-webkit-scrollbar-thumb:hover': {
                  background: '#a8a8a8'
                }
              }}
            >
              <Table stickyHeader size={isMobile ? "small" : "medium"}>
                <TableHead>
                  <TableRow sx={{ bgcolor: '#f5f7fa', position: 'sticky', top: 0, zIndex: 10 }}>
                    {getFieldConfig() && getFieldConfig().length > 0 ? (
                      <>
                        {getFieldConfig().map((field) => (
                          <TableCell 
                            key={field.key} 
                            sx={{ 
                              fontWeight: 'bold', 
                              bgcolor: '#e3f2fd',
                              fontSize: isMobile ? '0.75rem' : '0.875rem',
                              padding: isMobile ? '6px 4px' : '12px 8px',
                              whiteSpace: 'normal',
                              wordBreak: 'break-word',
                              minWidth: getMinWidthForField(field.key),
                              maxWidth: isMobile ? '120px' : '160px',
                              verticalAlign: 'top',
                              borderRight: '1px solid #e0e0e0',
                              position: 'relative'
                            }}
                            title={field.label} // 鼠标悬停显示完整标签
                          >
                            <Box sx={{
                              wordWrap: 'break-word',
                              lineHeight: 1.3,
                              pr: 0.5
                            }}>
                              {field.label}
                              {field.required && <span style={{ color: 'red' }}> *</span>}
                            </Box>
                          </TableCell>
                        ))}
                        <TableCell 
                          sx={{ 
                            fontWeight: 'bold', 
                            bgcolor: '#e3f2fd',
                            fontSize: isMobile ? '0.75rem' : '0.875rem',
                            padding: isMobile ? '6px 4px' : '12px 8px',
                            whiteSpace: 'normal',
                            minWidth: 120,
                            maxWidth: isMobile ? '120px' : '160px',
                            verticalAlign: 'top',
                            borderRight: '1px solid #e0e0e0'
                          }}
                        >
                          操作
                        </TableCell>
                      </>
                    ) : (
                      <TableCell 
                        colSpan={1} 
                        align="center" 
                        sx={{ 
                          fontWeight: 'bold', 
                          bgcolor: '#e3f2fd',
                          fontSize: isMobile ? '0.75rem' : '0.875rem',
                          padding: isMobile ? '6px 4px' : '12px 8px'
                        }}
                      >
                        加载中...
                      </TableCell>
                    )}
                  </TableRow>
                </TableHead>
                <TableBody>
                  {filteredRecords.length > 0 ? (
                    filteredRecords.map((record) => (
                      <TableRow 
                        key={record.id} 
                        hover 
                        sx={{ 
                          '&:last-child td, &:last-child th': { border: 0 },
                          transition: 'all 0.2s ease',
                          '&:hover': {
                            bgcolor: 'rgba(25, 118, 210, 0.05)',
                            transform: 'translateY(-1px)',
                            boxShadow: '0 2px 8px rgba(0, 0, 0, 0.08)'
                          },
                          '&:nth-of-type(even)': {
                            backgroundColor: isMobile ? 'transparent' : 'rgba(0, 0, 0, 0.02)'
                          }
                        }}
                      >
                        {getFieldConfig() && getFieldConfig().length > 0 ? (
                          getFieldConfig().map((field) => (
                            <TableCell 
                            key={`${record.id}-${field.key}`}
                            sx={{ 
                              fontSize: isMobile ? '0.75rem' : '0.875rem',
                              padding: isMobile ? '6px 4px' : '12px 8px',
                              wordBreak: 'break-word',
                              overflow: 'hidden',
                              textOverflow: 'ellipsis',
                              minWidth: getMinWidthForField(field.key),
                              maxWidth: isMobile ? '120px' : '160px',
                              verticalAlign: 'middle',
                              borderRight: '1px solid #f0f0f0'
                            }}
                            title={getFieldValue(record, field.key)} // 鼠标悬停显示完整内容
                          >
                            {getFieldValue(record, field.key)}
                          </TableCell>
                          ))
                        ) : (
                          <TableCell 
                            key={`${record.id}-loading`}
                            sx={{ 
                              fontSize: isMobile ? '0.75rem' : '0.875rem',
                              padding: isMobile ? '6px 4px' : '12px 8px',
                              wordBreak: 'break-word',
                              overflow: 'hidden',
                              textOverflow: 'ellipsis',
                              verticalAlign: 'middle',
                              borderRight: '1px solid #f0f0f0'
                            }}
                          >
                            加载中...
                          </TableCell>
                        )}
                        <TableCell 
                          sx={{ 
                            fontSize: isMobile ? '0.75rem' : '0.875rem',
                            padding: isMobile ? '6px 4px' : '12px 8px',
                            verticalAlign: 'middle',
                            whiteSpace: 'nowrap',
                            borderRight: '1px solid #f0f0f0'
                          }}
                        >
                          <Box sx={{ display: 'flex', flexWrap: isMobile ? 'column' : 'nowrap', gap: 0.5 }}>
                            <ActionButton 
                              variant="contained" 
                              size={isMobile ? "small" : "medium"} 
                              onClick={() => handleOpenForm(record)}
                              disabled={!user_profile?.can_edit_maintenance_records} // 根据权限控制
                              sx={{ 
                                mr: isMobile ? 0 : 0.5, 
                                mb: isMobile ? 0.5 : 0, 
                                minWidth: isMobile ? '60px' : '70px',
                                fontSize: isMobile ? '0.7rem' : '0.8rem',
                                padding: isMobile ? '4px 6px' : '6px 12px',
                                width: '100%',
                                flex: 1
                              }}
                            >
                              编辑
                            </ActionButton>
                            {hasDeletePermission && user_profile?.can_delete_maintenance_records && (
                              <ActionButton 
                                variant="outlined" 
                                color="error" 
                                size={isMobile ? "small" : "medium"} 
                                onClick={() => deleteRecord(record.id)}
                                sx={{ 
                                  minWidth: isMobile ? '60px' : '70px',
                                  fontSize: isMobile ? '0.7rem' : '0.8rem',
                                  padding: isMobile ? '4px 6px' : '6px 12px',
                                  width: '100%',
                                  flex: 1
                                }}
                              >
                                删除
                              </ActionButton>
                            )}
                          </Box>
                        </TableCell>
                      </TableRow>
                    ))
                  ) : (
                    <TableRow>
                      <TableCell 
                        colSpan={getFieldConfig()?.length + 1 || 1} 
                        align="center" 
                        sx={{ 
                          py: isMobile ? 3 : 6,
                          fontSize: isMobile ? '0.9rem' : 'inherit',
                          minHeight: isMobile ? '300px' : '400px'
                        }}
                      >
                        <Box sx={{ textAlign: 'center', display: 'flex', flexDirection: 'column', justifyContent: 'center', alignItems: 'center', height: '100%' }}>
                          <Typography variant={isMobile ? "h6" : "h5"} color="text.secondary">
                            暂无符合条件的维修记录
                          </Typography>
                          <Typography variant={isMobile ? "body2" : "body1"} color="text.secondary" sx={{ mt: 1 }}>
                            尝试调整筛选条件或点击"新建记录"添加数据
                          </Typography>
                        </Box>
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </TableContainer>
          </Box>
        </Paper>
      </StyledPaper>

      {/* 表单对话框 */}
      <Dialog 
        open={openForm} 
        onClose={handleCloseForm} 
        maxWidth="md" 
        fullWidth
        fullScreen={isMobile}
        PaperProps={{
          sx: {
            margin: isMobile ? 1 : 2,
            width: isMobile ? 'calc(100% - 32px)' : 'auto',
            maxHeight: isMobile ? 'calc(100% - 32px)' : '80vh',
          }
        }}
      >
        <DialogTitle sx={{ 
          background: 'linear-gradient(135deg, #1976d2 0%, #2196f3 100%)',
          color: 'white',
          pb: 2
        }}>
          <Box sx={{ display: 'flex', alignItems: 'center' }}>
            <Box sx={{ flexGrow: 1 }}>
              {currentRecord ? '编辑维修记录' : '新建维修记录'}
            </Box>
            <Chip 
                label={`${currentPhaseDisplay} - ${currentShiftTypeDisplay}`} 
                color="default" 
                size="small"
                sx={{ 
                  bgcolor: 'rgba(255, 255, 255, 0.2)', 
                  color: 'white',
                  fontWeight: 600
                }}
              />
          </Box>
        </DialogTitle>
        <LocalizationProvider dateAdapter={AdapterDateFns} adapterLocale={zhCN}>
          <form onSubmit={handleSubmit}>
            <DialogContent dividers sx={{ p: isMobile ? 1 : 3 }}>
              <Grid container spacing={isMobile ? 1.5 : 2}>
                {/* 显示只读的序号和月份字段 */}
                <Grid item xs={12} sm={6}>
                  <TextField
                    fullWidth
                    label="序号"
                    value={formData.serial_number || "系统自动生成"}
                    variant="outlined"
                    size={isMobile ? "small" : "medium"}
                    InputProps={{
                      readOnly: true,
                    }}
                    disabled={!!currentRecord} // 编辑时也禁用
                  />
                </Grid>
                <Grid item xs={12} sm={6}>
                  <TextField
                    fullWidth
                    label="月份"
                    value={formData.month || new Date().getMonth() + 1 + "月"}
                    variant="outlined"
                    size={isMobile ? "small" : "medium"}
                    InputProps={{
                      readOnly: true,
                    }}
                  />
                </Grid>
                {getFormFieldsConfig().map((field) => (
                  <Grid item xs={12} sm={6} key={field.key}>
                    {field.key === 'start_date_time' || field.key === 'end_date_time' ? (
                      <DateTimePicker
                        label={field.label}
                        value={formData[field.key] ? new Date(formData[field.key]) : null}
                        onChange={(newValue) => handleDateTimeChange(field.key, newValue)}
                        renderInput={(params) => (
                          <TextField
                            {...params}
                            fullWidth
                            required={field.required}
                            size={isMobile ? "small" : "medium"}
                          />
                        )}
                      />
                    ) : field.key === 'production_line' ? (
                      <Autocomplete
                        options={configData.productionLines ? 
                          configData.productionLines
                            .filter(line => 
                              // 根据当前的分期来过滤产线
                              // effectivePhase 是 'phase_1' 或 'phase_2'，而配置数据中的 phase_code 也是相同的格式
                              (effectivePhase === 'phase_1' && line.phase_code === 'phase_1') ||
                              (effectivePhase === 'phase_2' && line.phase_code === 'phase_2') ||
                              effectivePhase === 'both' // 如果是both则显示所有
                            )
                            .map(line => line.name) 
                          : []} // 使用配置数据中的名称
                        value={formData[field.key] || ''}
                        onChange={(event, newValue) => handleInputChange({ target: { name: field.key, value: newValue || '' } })}
                        renderInput={(params) => (
                          <TextField
                            {...params}
                            label={field.label}
                            name={field.key}
                            required={field.required}
                            variant="outlined"
                            size={isMobile ? "small" : "medium"}
                          />
                        )}
                      />
                    ) : field.key === 'process' ? (
                      <Autocomplete
                        options={configData.processes ? configData.processes.map(proc => proc.name) : []} // 使用配置数据中的工序名称
                        value={formData[field.key] || ''}
                        onChange={(event, newValue) => handleInputChange({ target: { name: field.key, value: newValue || '' } })}
                        renderInput={(params) => (
                          <TextField
                            {...params}
                            label={field.label}
                            name={field.key}
                            required={field.required}
                            variant="outlined"
                            size={isMobile ? "small" : "medium"}
                          />
                        )}
                      />
                    ) : field.key === 'equipment_name' ? (
                      <Autocomplete
                        freeSolo
                        options={assets ? 
                          assets
                            .filter(asset => 
                              // 根据当前分期和选定的产线来过滤设备
                              ((effectivePhase === 'phase_1' && asset.phase === 'phase_1') ||
                              (effectivePhase === 'phase_2' && asset.phase === 'phase_2') ||
                              effectivePhase === 'both') &&
                              (formData.production_line ? asset.production_line === formData.production_line : true)
                            )
                            .map(asset => asset.name)
                            .filter((name, index, self) => name && self.indexOf(name) === index) 
                          : []} // 去重并过滤空值
                        value={formData[field.key] || ''}
                        onChange={(event, newValue) => handleInputChange({ target: { name: field.key, value: newValue || '' } })}
                        onInputChange={(event, newInputValue) => handleInputChange({ target: { name: field.key, value: newInputValue || '' } })}
                        renderInput={(params) => (
                          <TextField
                            {...params}
                            label={field.label}
                            name={field.key}
                            required={field.required}
                            variant="outlined"
                            size={isMobile ? "small" : "medium"}
                          />
                        )}
                      />
                    ) : field.key === 'equipment_number' ? (
                      <Autocomplete
                        freeSolo
                        options={assets ? 
                          assets
                            .filter(asset => 
                              // 根据当前分期和选定的产线来过滤设备编号
                              ((effectivePhase === 'phase_1' && asset.phase === 'phase_1') ||
                              (effectivePhase === 'phase_2' && asset.phase === 'phase_2') ||
                              effectivePhase === 'both') &&
                              (formData.production_line ? asset.production_line === formData.production_line : true)
                            )
                            .map(asset => asset.asset_number)
                            .filter((number, index, self) => number && self.indexOf(number) === index) 
                          : []} // 去重并过滤空值
                        value={formData[field.key] || ''}
                        onChange={(event, newValue) => handleInputChange({ target: { name: field.key, value: newValue || '' } })}
                        onInputChange={(event, newInputValue) => handleInputChange({ target: { name: field.key, value: newInputValue || '' } })}
                        renderInput={(params) => (
                          <TextField
                            {...params}
                            label={field.label}
                            name={field.key}
                            required={field.required}
                            variant="outlined"
                            size={isMobile ? "small" : "medium"}
                          />
                        )}
                      />
                    ) : field.key === 'implementer' ? (
                      <Autocomplete
                        multiple
                        options={implementersOptions}
                        value={selectedImplementers}
                        onChange={(event, newValue) => {
                          handleImplementersChange(newValue);
                          handleMultiSelectChange(field.key, newValue);
                        }}
                        renderOption={(props, option) => (
                          <li {...props}>{option}</li>
                        )}
                        renderInput={(params) => (
                          <TextField
                            {...params}
                            label={field.label}
                            name={field.key}
                            required={field.required}
                            variant="outlined"
                            size={isMobile ? "small" : "medium"}
                            helperText="第一个实施人必须是当前用户"
                          />
                        )}
                      />
                    ) : field.key === 'duration' ? (
                      <TextField
                        fullWidth
                        label={field.label}
                        name={field.key}
                        value={formData[field.key] || ''}
                        onChange={handleInputChange}
                        required={field.required}
                        variant="outlined"
                        size={isMobile ? "small" : "medium"}
                        InputProps={{
                          readOnly: true, // 设置为只读，因为自动计算
                        }}
                        helperText="自动计算：(结束时间 - 开始时间) / 60分钟"
                      />
                    ) : (
                      <TextField
                        fullWidth
                        label={field.label}
                        name={field.key}
                        value={formData[field.key] || ''}
                        onChange={handleInputChange}
                        required={field.required}
                        variant="outlined"
                        size={isMobile ? "small" : "medium"}
                      />
                    )}
                  </Grid>
                ))}
              </Grid>
            </DialogContent>
            <DialogActions sx={{ p: isMobile ? 1.5 : 2, gap: 1 }}>
              <ActionButton 
                onClick={handleCloseForm} 
                variant="outlined"
                color="secondary"
                sx={{ minWidth: isMobile ? '100px' : '120px' }}
              >
                取消
              </ActionButton>
              <ActionButton 
                type="submit" 
                variant="contained" 
                color="primary"
                sx={{ minWidth: isMobile ? '100px' : '120px' }}
              >
                {currentRecord ? '更新' : '创建'}
              </ActionButton>
            </DialogActions>
          </form>
        </LocalizationProvider>
      </Dialog>

      {/* 通知 */}
      <Snackbar
        open={snackbar.open}
        autoHideDuration={6000}
        onClose={() => setSnackbar({ ...snackbar, open: false })}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
      >
        <Alert
          onClose={() => setSnackbar({ ...snackbar, open: false })}
          severity={snackbar.severity}
          sx={{ width: '100%' }}
        >
          {snackbar.message}
        </Alert>
      </Snackbar>

      {/* 下载记录对话框 */}
      <Dialog 
        open={openDownloadDialog} 
        onClose={() => setOpenDownloadDialog(false)} 
        maxWidth="sm" 
        fullWidth
      >
        <DialogTitle>下载维修记录 ({currentPhaseDisplay} - {currentShiftTypeDisplay})</DialogTitle>
        <DialogContent dividers sx={{ p: 3 }}>
          <Grid container spacing={2}>
            <Grid item xs={12}>
              <FormControl fullWidth variant="outlined" size="medium">
                <InputLabel>期数</InputLabel>
                <Select
                  value={downloadFilters.phase}
                  onChange={(e) => setDownloadFilters({...downloadFilters, phase: e.target.value})}
                  label="期数"
                >
                  {/* 管理员可以查看所有期数，普通用户只能查看自己分配的期数 */}
                  {user_profile && user_profile.type === 'Admin' ? (
                    <>
                      <MenuItem value="phase_1">一期</MenuItem>
                      <MenuItem value="phase_2">二期</MenuItem>
                    </>
                  ) : (
                    <MenuItem value={effectivePhase}>
                      {effectivePhase === 'phase_1' ? '一期' : '二期'}
                    </MenuItem>
                  )}
                </Select>
              </FormControl>
            </Grid>
            <Grid item xs={12}>
              <FormControl fullWidth variant="outlined" size="medium">
                <InputLabel>班次类型</InputLabel>
                <Select
                  value={downloadFilters.shift_type}
                  onChange={(e) => setDownloadFilters({...downloadFilters, shift_type: e.target.value})}
                  label="班次类型"
                >
                  {/* 管理员可以查看所有班次类型，普通用户只能查看自己分配的班次类型 */}
                  {user_profile && user_profile.type === 'Admin' ? (
                    <>
                      <MenuItem value="long_day_shift">长白班</MenuItem>
                      <MenuItem value="rotating_shift">倒班</MenuItem>
                    </>
                  ) : (
                    <MenuItem value={effectiveShiftType}>
                      {effectiveShiftType === 'long_day_shift' ? '长白班' : '倒班'}
                    </MenuItem>
                  )}
                </Select>
              </FormControl>
            </Grid>
          </Grid>
        </DialogContent>
        <DialogActions sx={{ p: 2, gap: 1 }}>
          <ActionButton 
            onClick={() => setOpenDownloadDialog(false)} 
            variant="outlined"
            color="secondary"
          >
            取消
          </ActionButton>
          <ActionButton 
            onClick={handleDownloadRecords} 
            variant="contained" 
            color="primary"
          >
            下载记录
          </ActionButton>
        </DialogActions>
      </Dialog>
    </Container>
  );
};

export default PhaseShiftMaintenanceRecords;